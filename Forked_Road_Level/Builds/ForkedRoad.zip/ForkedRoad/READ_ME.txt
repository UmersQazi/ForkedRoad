Click on ForkedRoad.exe to start
Press Backspace to restart the level
Press Esc to exit the application
WASD or Arrow keys to move